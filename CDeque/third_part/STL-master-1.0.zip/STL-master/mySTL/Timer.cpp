#include"Timer.h"
namespace STL {
	clock_t Timer::m_startTime;
	clock_t Timer::m_endTime;
	clock_t Timer::m_usedTime;
	
}