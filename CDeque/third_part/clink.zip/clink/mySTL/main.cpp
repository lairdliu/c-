#include"link.h"
#include<stdlib.h>
#include<iostream>
using namespace std;

void Test1()
{
	int i = 0;
	CDeque list1;

	for (i = 0; i < 10; i++)
	{
		list1.push_back((void*)&i);
	}
	list1.PrintSList();

	CDeque list2 = list1;
	list2.PrintSList();

	list2.pop_back();
	list2.PrintSList();

	i = 100;
	list2.push_front((void*)&i);
	list2.PrintSList();

	list2.pop_front();
	list2.PrintSList();

	i = 100;
	list2.push_back((void*)&i);
	list2.PrintSList();

	list2.pop_back();
	list2.PrintSList();
	
	int ret1=list2.size();
	cout <<"list2.size():" <<ret1 << endl;

	i = 100;
	list2.insert(5, (void*)&i);
	list2.PrintSList();

	list2.erase(5);
	list2.PrintSList();

	list2.n_erase(5,3);
	list2.PrintSList();

	cout <<"list2.at(2):"<< *(int*)list2.at(2) << endl;

	list2.clear();
	list2.PrintSList();
}

int main()
{
	Test1();
	system("pause");
}
