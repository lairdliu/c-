#include<iostream>
#include<stack>
#include<vector>
#include<deque>
#include<map>
#include<string>
#include"TestDeque.h"
#include<functional>
int main() {

	STL::testDeque::myTest();
	
	//STL::testDeque::testConstruct();
	//STL::testDeque::testItemOp();
	//STL::testDeque::testGetOp();
	system("pause");
	return 0;
}