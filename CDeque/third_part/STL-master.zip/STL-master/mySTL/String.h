#pragma once
namespace STL {
	class string {
		//
	};
}