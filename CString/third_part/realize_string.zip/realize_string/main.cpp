#include "MyString.h"
#include <iostream>
using namespace std;

int main()
{
    int n;
    int choose = 1;
    int p,l;
    char cs[100];
    MyString s1;
    MyString s2("hello");
    MyString s3 = "HELLO";
    cout << "***** welcome *****\n";
    cout << "******* MADE BY zyp **********\n";
    cout << "s1= " << s1 << "s2= " << s2 << "s3= " << s3 << endl;
    cout << "������һ������С��100���ַ���������world\n";
    cin >> s1;
    s1 = s1;
    //s1 = s1+s1;
    s1 += s1;
    MyString s4(s1);
    s4.append(s1);
    s2.insert(2,s3);
    s1.erase(4,4);
    s1.assign(s2,1,7);
    cout << "s1= " << s1 << "s2= " << s2 << "s3= " << s3 << "s4= " << s4 << endl;
    s2 = s4.substr(2,7);
    cout << "s4[3]= " << s4[3] << s4.length() << (s1>=s2) << "s4.substr() " << s2 << endl;
    cout << "s1.find_first_of(beLE,2)��" << s1.find_first_of("beLE",2) << ",s1.find_first_of(a,3):" << s1.find_first_of('a',3) << ",s1.find_first_of(s3,2):" << s1.find_first_of(s3,2) << endl;
    MyString s5(5,'b');
    s5 += s5;
    //s5.append(s5);// ��֪��Ϊʲ���ǲ���append
    cout << "s5 = " << s5 << "s5.find_first_not_of(aeHLEOl,2)��" << s5.find_first_not_of("aeHLEOl",2) << "s5.find_first_not_of(aeHLEOl,0)��" << s5.find_first_not_of("aeHLEOl") << endl;
    cout << "s5.find_first_not_of(s1,2)��" << s5.find_first_not_of(s1,2) << "s5.find_first_not_of(b,2)��" << s5.find_first_not_of('b',2) << endl;
    swap(s1,s5);
    s5.replace_all('a','J');
    MyString s6("LLO");
    cout << s1 << "," << s5 << "s5.find(LLO,0) " << s5.find("LLO",0) << "s5.find(s6,0) " << s5.find(s5) << endl;
    cout << npos << endl;
    return 0;
}
